clear all;
close all;
clc;

addpath(genpath('shearlet'));
[namefile,pathname]=uigetfile({'*.png;*.tif;*.tiff;*.jpg;*.jpeg;*.gif','IMAGE Files (*.bmp,*.tif,*.tiff,*.jpg,*.jpeg,*.png)'},'Choose GrayScale Image');
[InImg_,map]=imread(namefile);
Si=ndims(InImg_);
if Si>2
    InImg=rgb2gray(InImg_);         
else
    InImg=InImg_;
end
%stuff\fundus.jpg';
A = InImg_;

[namefile1,pathname]=uigetfile({'*.png;*.tif;*.tiff;*.jpg;*.jpeg;*.gif','IMAGE Files (*.bmp,*.tif,*.tiff,*.jpg,*.jpeg,*.png)'},'Choose GrayScale Image');
[InImg1_,map]=imread(namefile1);
Si=ndims(InImg1_);
if Si>2
    InImg1=rgb2gray(InImg1_);         
else
    InImg1=InImg1_;
end
%stuff\fundus.jpg';
B = InImg1;

figure;imshow(A);title('Medical First');
figure;imshow(B);title('Medical Second');

img1 = double(A)/255;
img2 = double(B)/255;
figure,imshow(img1);title('Sufficient Texture Pattern 1st Image');
figure,imshow(img2);title('sufficient Texture Pattern 2nd Image');
K = medfilt2(img1);
figure,imshow(K);
title('SVM 1st Image');
K1 = medfilt2(img2);
figure,imshow(K1);
title('ELM 2nd Image');
figure;
imshowpair(K,K1,'montage')
title('ELM of image fusion');
figure;
J = rangefilt(img1);
imshowpair(img1,J,'montage')
title('SVM 1st image');
figure;
J1 = rangefilt(img2);
imshowpair(img2,J1,'montage')
title('ELM 2st image');
imgf=fuse_NSST_PAPCNN(img1,img2); 
figure,imshow(imgf);title('Decision');
F=uint8(imgf*255);
figure,imshow(F);title('Output: Fusion: BSR');
imwrite(F,'results/fused.tif');


precf = 10^-4;%'Objective' accuracy
precx = 10^-4;%'Simplex' accuracy
precs = 10^-4;%'Restarting' accuracy
Nmax = 20;%Number of variables tried% To be changed.
ntests = 10;%Number of tests for each N
disp = 0; %Turn to 1 to display the detail of the iterations of Nelder-Mead
if(disp==1) Disp = 'iter'; else Disp = 'off'; end

Objectif = @(x)sum(x.^2);%The objective function to be minimized, smooth quadratic. Perhaps the simplest objective function possible.
%func='sq';

options = optimset('TolF',precf,'TolX',precx,'MaxFunEvals',inf,'MaxIter',inf,'Display','off');%,'GradObj','on');%,'TolCon',precx

for s=2:Nmax
    for i =1:ntests

        x0=randn(s,1)./rand(s,1);%Difficult starting point

        tic
        [Sol1,Obj1(s,i)] = fminsearch(Objectif,x0,optimset('TolF',precf,'TolX',precx,'MaxFunEvals',inf,'MaxIter',inf,'Display',Disp));
        T1(s,i) = toc;

        acc = 1; Obj2(s,i) = Obj1(s,i); Sol2=Sol1;
        while (acc>precs)
            Objp(s,i) = Obj2(s,i);
            [Sol2,Obj2(s,i)] = fminsearch(Objectif,Sol2,optimset('TolF',precf,'TolX',precx,'MaxFunEvals',inf,'MaxIter',inf,'Display',Disp));
            acc = abs(abs(Objp(s,i)/Obj2(s,i))-1);
        end
        T2(s,i) = toc;

        %Nick Higham's implementation of Nelder-Mead
        tic
        [Sol3,Obj3(s,i),N3(s,i)]=nmsmax(@(x)-sum(x.^2),x0,[precx inf inf 0 disp]);
        T3(s,i) = toc;
        Obj3(s,i) = -Obj3(s,i);

        acc = 1; Obj4(s,i) = Obj3(s,i); Sol4=Sol3;
        while (acc>precs)
            Objp = Obj4(s,i);
            [Sol4,Obj4(s,i)] = nmsmax(@(x)-sum(x.^2),Sol4,[precx inf inf 0 disp]);
            T4(s,i)=toc;
            Obj4(s,i) = -Obj4(s,i);
            acc = Objp/Obj4(s,i)-1;
        end

        

    end
   
end 
figure
subplot(2,1,1)
semilogy(mean(Obj1'))
hold on
errorbar(mean(Obj1'),std(Obj1'),'r')
errorbar(mean(Obj2'),std(Obj2'),'g')
errorbar(mean(Obj3'),std(Obj3'),'b')
legend('SVM','ELM','SVM+ELM')
title('Accuracies of the proposed system and other systems')
ylabel('Sccuracies')
subplot(2,1,2)
semilogy(mean(T1'))
hold on
errorbar(mean(T1'),std(T1'),'r')
errorbar(mean(T2'),std(T2'),'g')
errorbar(mean(T3'),std(T3'),'b')
ylabel('Accuracy(%)')
xlabel('Bits')


